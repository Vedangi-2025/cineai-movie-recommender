// ============================================================
// CineAI – Anthropic API Client
// Handles all communication with the Claude API
// ============================================================

import { CONFIG } from "./config.js";

/**
 * Builds the recommendation prompt from user preferences.
 * This is the core of the content-based filtering logic.
 */
export function buildPrompt(preferences) {
  const { genres, mood, favMovies, minRating, era, language } = preferences;

  return `You are a world-class film critic and personalised recommendation engine.

A user wants movie recommendations based on the following preferences:
- Preferred genres: ${genres.length > 0 ? genres.join(", ") : "open to anything"}
- Current mood: ${mood || "flexible — any mood"}
- Minimum IMDb rating: ${minRating}/10
- Era: ${era}
- Language: ${language}
- Reference movies they have loved: ${favMovies.length > 0 ? favMovies.join(", ") : "none provided"}

Your task:
Recommend exactly ${CONFIG.NUM_RECOMMENDATIONS} movies that best match these preferences.
Use collaborative filtering logic: if reference movies are provided, find patterns in genre, director style, themes, pacing, and tone — then recommend similar but distinct movies the user likely hasn't seen.
If no references are given, use content-based filtering purely on genre, mood, era, and language.

STRICT RULES:
- Only recommend real movies with verified IMDb ratings at or above ${minRating}
- Ensure variety — do not recommend sequels of the same franchise back to back
- If language preference is set, prioritise that language
- Return ONLY a valid JSON array — no markdown code blocks, no explanation text outside the JSON

Return a JSON array of exactly ${CONFIG.NUM_RECOMMENDATIONS} objects. Each object must have:
{
  "title": "string — exact movie title",
  "year": number — release year,
  "rating": "string — e.g. 8.4/10",
  "genres": ["array", "of", "2-3 genre strings"],
  "director": "string — director name",
  "matchReason": "string — max 10 words explaining why it matches user taste",
  "description": "string — 2 sentences: one plot summary, one emotional hook",
  "whyWatch": "string — 1 unique sentence about what makes this film special"
}`;
}

/**
 * Calls the Anthropic Claude API with the given prompt.
 * Returns parsed movie recommendation data.
 */
export async function fetchRecommendations(preferences) {
  const prompt = buildPrompt(preferences);

  const response = await fetch(CONFIG.API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      // NOTE: In production, NEVER expose your API key in frontend code.
      // Use a backend proxy server instead. See docs/DEPLOYMENT.md
      "x-api-key": CONFIG.API_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: CONFIG.MODEL,
      max_tokens: CONFIG.MAX_TOKENS,
      messages: [{ role: "user", content: prompt }],
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(
      err?.error?.message || `API error: ${response.status} ${response.statusText}`
    );
  }

  const data = await response.json();
  const rawText = data.content
    .filter((block) => block.type === "text")
    .map((block) => block.text)
    .join("");

  // Strip accidental markdown fences if model adds them
  const cleaned = rawText.replace(/```json|```/gi, "").trim();

  let movies;
  try {
    movies = JSON.parse(cleaned);
  } catch {
    throw new Error("The AI returned an unexpected format. Please try again.");
  }

  if (!Array.isArray(movies) || movies.length === 0) {
    throw new Error("No recommendations returned. Try adjusting your preferences.");
  }

  return movies;
}
