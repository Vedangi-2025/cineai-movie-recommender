// ============================================================
// CineAI – API Configuration
// ============================================================
// Add your Anthropic API key in the .env file:
//   ANTHROPIC_API_KEY=your_key_here
//
// For browser/demo use, you can set it directly here (not for production):
//   export const API_KEY = "sk-ant-...";
// ============================================================

export const CONFIG = {
  // Replace with your actual API key or load from environment
  API_KEY: typeof process !== "undefined" && process.env?.ANTHROPIC_API_KEY
    ? process.env.ANTHROPIC_API_KEY
    : "", // <-- paste your key here for local testing

  MODEL: "claude-sonnet-4-6",
  MAX_TOKENS: 1500,
  API_URL: "https://api.anthropic.com/v1/messages",

  // Number of recommendations to return
  NUM_RECOMMENDATIONS: 5,
};
