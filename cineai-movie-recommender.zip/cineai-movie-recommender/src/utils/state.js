// ============================================================
// CineAI – State Management
// Manages user preference state throughout the session
// ============================================================

/**
 * Central application state.
 * All preference data lives here so it can be easily read
 * and passed to the API layer.
 */
const state = {
  selectedGenres: new Set(),
  selectedMood: "",
  favMovies: [],
  minRating: 7.0,
  era: "any era",
  language: "any language",
};

// ---- Genre state ----

export function toggleGenre(genre) {
  if (state.selectedGenres.has(genre)) {
    state.selectedGenres.delete(genre);
    return false; // removed
  } else {
    state.selectedGenres.add(genre);
    return true; // added
  }
}

export function getGenres() {
  return [...state.selectedGenres];
}

// ---- Mood state ----

export function setMood(mood) {
  state.selectedMood = mood;
}

export function getMood() {
  return state.selectedMood;
}

// ---- Favourite movies ----

export function addFavMovie(movie) {
  const trimmed = movie.trim();
  if (!trimmed || state.favMovies.includes(trimmed)) return false;
  state.favMovies.push(trimmed);
  return true;
}

export function removeFavMovie(movie) {
  const idx = state.favMovies.indexOf(movie);
  if (idx !== -1) state.favMovies.splice(idx, 1);
}

export function getFavMovies() {
  return [...state.favMovies];
}

// ---- Preferences ----

export function setRating(val) {
  state.minRating = parseFloat(val);
}

export function setEra(val) {
  state.era = val;
}

export function setLanguage(val) {
  state.language = val;
}

// ---- Get all preferences for API ----

export function getAllPreferences() {
  return {
    genres: getGenres(),
    mood: getMood(),
    favMovies: getFavMovies(),
    minRating: state.minRating,
    era: state.era,
    language: state.language,
  };
}

// ---- Validation ----

export function validatePreferences() {
  const prefs = getAllPreferences();

  if (prefs.genres.length === 0 && !prefs.mood) {
    return {
      valid: false,
      message: "Please select at least one genre or mood before getting recommendations.",
    };
  }

  return { valid: true, message: "" };
}
