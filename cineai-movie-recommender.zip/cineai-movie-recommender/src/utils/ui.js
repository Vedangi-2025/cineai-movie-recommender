// ============================================================
// CineAI – UI Utilities
// Handles rendering of movie cards and UI states
// ============================================================

/**
 * Renders a single movie card element.
 * @param {Object} movie - Movie data from API
 * @param {number} index - Position in results list (0-indexed)
 * @returns {HTMLElement}
 */
export function createMovieCard(movie, index) {
  const card = document.createElement("article");
  card.className = "movie-card";
  card.setAttribute("aria-label", `Movie recommendation ${index + 1}: ${movie.title}`);
  card.style.animationDelay = `${index * 0.08}s`;

  const genreTags = (movie.genres || [])
    .map((g) => `<span class="genre-tag">${escapeHtml(g)}</span>`)
    .join("");

  card.innerHTML = `
    <div class="movie-top">
      <div>
        <p class="movie-rank">Pick #${index + 1}</p>
        <h2 class="movie-title">${escapeHtml(movie.title)}</h2>
        <div class="movie-meta">
          <span>${movie.year || "—"}</span>
          <span class="meta-dot">·</span>
          <span>⭐ ${escapeHtml(String(movie.rating || "N/A"))}</span>
          ${movie.director ? `<span class="meta-dot">·</span><span>Dir. ${escapeHtml(movie.director)}</span>` : ""}
        </div>
      </div>
      <span class="match-badge">${escapeHtml(movie.matchReason || "Great match")}</span>
    </div>
    <div class="movie-genres">${genreTags}</div>
    <p class="movie-desc">${escapeHtml(movie.description || "")}</p>
    <div class="why-watch">
      <p class="why-label">Why watch it</p>
      <p class="why-text">${escapeHtml(movie.whyWatch || "")}</p>
    </div>
  `;

  return card;
}

/**
 * Renders all movie cards into the results panel.
 * @param {HTMLElement} container - The results container element
 * @param {Array} movies - Array of movie objects
 */
export function renderMovies(container, movies) {
  container.innerHTML = "";

  const header = document.createElement("div");
  header.className = "results-header";
  header.innerHTML = `<p class="results-count">Showing ${movies.length} recommendation${movies.length !== 1 ? "s" : ""} for you</p>`;
  container.appendChild(header);

  movies.forEach((movie, i) => {
    container.appendChild(createMovieCard(movie, i));
  });
}

/**
 * Shows a loading spinner with message.
 */
export function showLoading(container, message = "Finding your perfect movies...") {
  container.innerHTML = `
    <div class="loading-state" role="status" aria-live="polite">
      <div class="spinner" aria-hidden="true"></div>
      <p>${message}</p>
    </div>
  `;
}

/**
 * Shows an error message in the container.
 */
export function showError(container, message) {
  container.innerHTML = `
    <div class="error-state" role="alert">
      <strong>Something went wrong</strong><br/>
      ${escapeHtml(message)}
    </div>
  `;
}

/**
 * Shows the default empty state.
 */
export function showEmptyState(container) {
  container.innerHTML = `
    <div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" width="48" height="48" aria-hidden="true">
        <rect x="2" y="2" width="20" height="20" rx="3"/>
        <path d="M7 2v20M17 2v20M2 12h20"/>
      </svg>
      <p>Your recommendations will appear here</p>
      <span>Pick your genres and mood, then click the button</span>
    </div>
  `;
}

/**
 * Renders a favourite movie tag.
 * @param {string} movie - Movie name
 * @param {Function} onRemove - Callback when remove is clicked
 * @returns {HTMLElement}
 */
export function createFavTag(movie, onRemove) {
  const tag = document.createElement("div");
  tag.className = "fav-tag";
  tag.innerHTML = `
    <span>${escapeHtml(movie)}</span>
    <button aria-label="Remove ${escapeHtml(movie)}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="12" height="12" aria-hidden="true">
        <path d="M18 6L6 18M6 6l12 12"/>
      </svg>
    </button>
  `;
  tag.querySelector("button").addEventListener("click", () => onRemove(movie));
  return tag;
}

/** Simple HTML escape to prevent XSS */
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
