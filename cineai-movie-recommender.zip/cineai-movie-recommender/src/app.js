// ============================================================
// CineAI – Main Application Entry Point
// Wires together UI events, state, and API calls
// ============================================================

import { fetchRecommendations } from "./api/claude.js";
import {
  toggleGenre,
  setMood,
  addFavMovie,
  removeFavMovie,
  getFavMovies,
  setRating,
  setEra,
  setLanguage,
  getAllPreferences,
  validatePreferences,
} from "./utils/state.js";
import {
  renderMovies,
  showLoading,
  showError,
  showEmptyState,
  createFavTag,
} from "./utils/ui.js";

// ---- DOM References ----
const genresContainer  = document.getElementById("genres");
const moodsContainer   = document.getElementById("moods");
const favInput         = document.getElementById("favInput");
const addFavBtn        = document.getElementById("addFavBtn");
const favTagsContainer = document.getElementById("favTags");
const ratingSlider     = document.getElementById("ratingSlider");
const ratingVal        = document.getElementById("ratingVal");
const eraSelect        = document.getElementById("era");
const languageSelect   = document.getElementById("language");
const getBtn           = document.getElementById("getBtn");
const resultsPanel     = document.getElementById("results");

// ---- Genre Interaction ----
genresContainer.querySelectorAll(".genre-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const added = toggleGenre(btn.dataset.val);
    btn.classList.toggle("active", added);
    btn.setAttribute("aria-pressed", String(added));
  });
});

// ---- Mood Interaction ----
moodsContainer.querySelectorAll(".mood-card").forEach((card) => {
  card.addEventListener("click", () => selectMood(card));
  card.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      selectMood(card);
    }
  });
});

function selectMood(selectedCard) {
  moodsContainer.querySelectorAll(".mood-card").forEach((c) => {
    c.classList.remove("active");
    c.setAttribute("aria-pressed", "false");
  });
  selectedCard.classList.add("active");
  selectedCard.setAttribute("aria-pressed", "true");
  setMood(selectedCard.dataset.val);
}

// ---- Favourite Movies ----
function renderFavTags() {
  favTagsContainer.innerHTML = "";
  getFavMovies().forEach((movie) => {
    const tag = createFavTag(movie, (m) => {
      removeFavMovie(m);
      renderFavTags();
    });
    favTagsContainer.appendChild(tag);
  });
}

function handleAddFav() {
  const val = favInput.value.trim();
  if (!val) return;
  const added = addFavMovie(val);
  if (added) {
    renderFavTags();
    favInput.value = "";
    favInput.focus();
  }
}

addFavBtn.addEventListener("click", handleAddFav);
favInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    handleAddFav();
  }
});

// ---- Rating Slider ----
ratingSlider.addEventListener("input", () => {
  const val = parseFloat(ratingSlider.value).toFixed(1);
  ratingVal.textContent = `${val}+`;
  setRating(val);
});

// ---- Era & Language ----
eraSelect.addEventListener("change", () => setEra(eraSelect.value));
languageSelect.addEventListener("change", () => setLanguage(languageSelect.value));

// ---- Get Recommendations ----
getBtn.addEventListener("click", handleGetRecommendations);

async function handleGetRecommendations() {
  const validation = validatePreferences();
  if (!validation.valid) {
    showError(resultsPanel, validation.message);
    return;
  }

  // UI loading state
  getBtn.classList.add("loading");
  getBtn.textContent = "Finding your movies...";
  showLoading(resultsPanel, "The AI is analysing your preferences...");

  try {
    const preferences = getAllPreferences();
    const movies = await fetchRecommendations(preferences);
    renderMovies(resultsPanel, movies);
    // Scroll to results on mobile
    if (window.innerWidth < 768) {
      resultsPanel.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  } catch (err) {
    console.error("[CineAI] Recommendation error:", err);
    showError(resultsPanel, err.message || "An unexpected error occurred. Please try again.");
  } finally {
    getBtn.classList.remove("loading");
    getBtn.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" width="20" height="20" aria-hidden="true">
        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
      </svg>
      Get my recommendations
    `;
  }
}

// ---- Init ----
showEmptyState(resultsPanel);
