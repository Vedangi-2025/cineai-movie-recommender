# Deployment Guide

## Option 1: GitHub Pages (Free, Easiest)

1. Push your code to a GitHub repository
2. Go to **Settings → Pages**
3. Set source to `main` branch, `/ (root)` folder
4. Click **Save** — your app will be live at `https://YOUR_USERNAME.github.io/cineai-movie-recommender/`

> ⚠️ For GitHub Pages, you need to hardcode the API key in `config.js`. This is fine for a personal/internship demo project. Do NOT do this for a public production app.

---

## Option 2: Vercel (Free, Professional)

1. Install Vercel CLI: `npm i -g vercel`
2. Run `vercel` in the project root
3. Add your API key as an environment variable in the Vercel dashboard
4. Update `config.js` to read from `process.env.ANTHROPIC_API_KEY`

---

## Option 3: Backend Proxy (Secure, Production-Grade)

For a real production app, never expose your API key in the browser. Use a Node.js proxy:

```js
// server.js (Node.js + Express)
import express from "express";
import fetch from "node-fetch";

const app = express();
app.use(express.json());
app.use(express.static("."));

app.post("/api/recommend", async (req, res) => {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,  // server-side only
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(req.body),
  });
  const data = await response.json();
  res.json(data);
});

app.listen(3000, () => console.log("Server running on http://localhost:3000"));
```

Then in `claude.js`, change the API URL to `/api/recommend` and remove the `x-api-key` header from the frontend.

---

## Environment Variables

Copy `.env.example` to `.env`:

```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

Never commit `.env` to GitHub — it's already in `.gitignore`.
